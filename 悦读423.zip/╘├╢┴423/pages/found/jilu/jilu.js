// pages/jilu/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    items: [
      { name: '记录1', time: '20191213' },
      { name: '记录2', time: '20191213' },
      { name: '记录3', time: '20191213' },
      { name: '记录4', time: '20191213' },
      { name: '记录5', time: '20191213' },
      { name: '记录6', time: '20191213' },
      { name: '记录7', time: '20191213' },
      { name: '记录8', time: '20191213' },
      { name: '记录9', time: '20191213' }
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  bindNavigation: function (e) {
    console.log(e.currentTarget.dataset.index)
    if (e.currentTarget.dataset.index === 0) {
      wx.navigateTo({
        url: "../myadd/myadd",
      })
    }
    if (e.currentTarget.dataset.index === 1) {
      wx.navigateTo({
        url: "../myadd/myadd",
      })
    }
    if (e.currentTarget.dataset.index === 2) {
      wx.navigateTo({
        url: "../myadd/myadd",
      })
    }
    if (e.currentTarget.dataset.index === 3) {
      wx.navigateTo({
        url: "../myadd/myadd",
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})