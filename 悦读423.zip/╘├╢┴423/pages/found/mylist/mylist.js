var timeFormat = require("../../../utils/util.js")


Page({
  onload: function () {
    initData(this);
  },
  onShow: function () {
    initData(this);
  },
  edit(e) {
    // 修改原有的记事本内容
    console.log("myedit")
    var myid = e.currentTarget.dataset.id;
    console.log(myid);
    wx.navigateTo({
      url: '../myadd/myadd?id=' + myid,
    })
  },
  add() {
    // 增加新的记事本内容
    console.log("my add");
    wx.navigateTo({
      url: '../myadd/myadd'
    })
  },
  data: {
    mylists: []
  }
})

// 每次onload和onshow从本地存储中获取数据
function initData(page) {
  var txt = wx.getStorageSync("txt");
  if (txt.length) {
    txt.forEach(function (item, i) {
      //  循环每一项数据，并格式化时间戳
      var t = new Date(Number(item.time));
      item.time = timeFormat.formatTime(t);
    })
  }
  page.setData({
    //  将获取到的数据绑定到本页面实例中
    mylists: txt
  })
}