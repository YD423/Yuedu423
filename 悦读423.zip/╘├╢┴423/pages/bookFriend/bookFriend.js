// pages/friends/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    menus: [
      { icon: '../../pic/s.png.jpg', title: '新的书友', unread: 2 },
      { icon: '../../pic/t.png.jpg', title: '群聊' },
      { icon: '../../pic/f.png.jpg', title: '标签' }
    ],
    friends: [
      { header: true, name: "D" },
      { avatar: '../../pic/ddm.png', name: '多多美' },
      { header: true, name: "H" },
      { avatar: '../../pic/hh.png', name: '灰灰' },
      { header: true, name: "X" },
      { avatar: '../../pic/nv.png', name: '小红' }
    ]
  },
  ql: function() {
    wx.navigateTo({
      url: 'message/message',
      success: function (res) { console.log(res) },
      fail: function (res) { console.log(res) },
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
